//
//  main.m
//  FreeTamilEbook
//
//  Created by Kishore on 20/1/14.
//  Copyright (c) 2014 KishoreK. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "FTEAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([FTEAppDelegate class]));
    }
}
