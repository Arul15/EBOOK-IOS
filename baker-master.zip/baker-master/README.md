Project Baker
=============

This is the original Baker Framework repository by Davide Casali, Marco Colombo and Alessandro Morandi. Note that this repo is not maintained anymore.

The new official fork can be found at https://github.com/bakerframework/baker/.
