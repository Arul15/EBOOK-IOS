

#include "UITableViewCellContentView.h"
@implementation UITableViewCellContentView

+ (id)alloc {
  return [UIView alloc];
}

+ (id)allocWithZone:(NSZone *)zone {
  return [UIView allocWithZone:zone];
}

@end