//
//  FTEViewController.m
//  FreeTamilEbook
//
//  Created by Kishore on 20/1/14.
//  Copyright (c) 2014 KishoreK. All rights reserved.
//

#import "FTEViewController.h"
#import "XMLDictionary.h"

@interface FTEViewController ()<UIWebViewDelegate>

@end

@implementation FTEViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
