This repo is not maintained anymore.

The new official fork can be found at https://github.com/bakerframework/baker/.
