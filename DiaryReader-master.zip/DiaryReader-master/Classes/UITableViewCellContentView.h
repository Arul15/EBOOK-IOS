#import <UIKit/UIKit.h>
@interface UITableViewCellContentView : UIView {
}
@end