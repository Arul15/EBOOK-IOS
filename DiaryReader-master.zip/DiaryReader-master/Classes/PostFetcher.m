//
//  PostFetcher.m
//  blogbook
//
//  Created by David Finucane on 2/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "PostFetcher.h"


@implementation PostFetcher

@end
