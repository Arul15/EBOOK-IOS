//
//  PostFetcher.h
//  blogbook
//
//  Created by David Finucane on 2/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PostFetcher : NSObject
{
  NSMutableArray*urls;
  
}

@end
